<?php
include("clientheader.php");
?>
<div class="container">
	<table class="table table-border">
		<tr>
			<th>S. No.</th>
			<th>Title</th>
			<th>Approval Status</th>
		</tr>
		<tr style="padding:3px; border: black thin; margin:3px; border-radius: 3px;">
			<td>1</td>
			<td>
				<a href="#">Checking</a>
			</td>
			<td>
			Approved
			<button> view</button>
			</td>
		</tr>
	</table>
</div>
</body>
</html>