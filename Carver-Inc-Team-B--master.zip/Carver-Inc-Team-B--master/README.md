# Carver-Inc-Team-B-
Software Engineering CSC7135 project

--To set up web server which would be used to run mysql and the php files in the web browser.
  ** XAMPP Server from apache is used to produce this functionality.Dowmload XAMPP.
--Ensure that the port number of XAMPP and your mysql have port number as 3308 , create a database and execute the queries in t123.sql
--Start the Apache and MySql part in the XAMPP Server.
--Go to any web browser and give localhost\ProjectName in the Address Bar.
--Admin and Client password are provided in the AdminandClientPassword.word
